import tkinter as tk
from tkinter import messagebox
from threading import Thread
from synAttack import syn_flood, demo_mode  # פונקציות מהקובץ השני

# משתנה לשליטה על עצירת ההתקפה
stop_attack = False

# פונקציה שמופעלת בלחיצה על הכפתור
def start_attack():
    global stop_attack
    stop_attack = False

    target_ip = ip_entry.get()
    target_port = port_entry.get()
    packet_count = count_entry.get()
    demo = demo_var.get()

    # בדיקה אם שדות ריקים
    if not target_ip or not target_port or not packet_count:
        messagebox.showerror("Error", "Please fill in all fields")
        return

    # בדיקה אם הפורט והכמות הם מספרים
    try:
        target_port = int(target_port)
        packet_count = int(packet_count)
    except ValueError:
        messagebox.showerror("Error", "Port and count must be numbers")
        return

    log_text.insert(tk.END, "Launching attack...\n")
    Thread(target=run_attack, args=(target_ip, target_port, packet_count, demo)).start()

# פונקציית הרצה בפועל
def run_attack(ip, port, count, demo):
    if demo:
        demo_mode(count, log_text, lambda: stop_attack)
    else:
        syn_flood(ip, port, count, log_text, lambda: stop_attack)

    if not stop_attack:
        log_text.insert(tk.END, "Attack completed!\n")
        log_text.see(tk.END)

# פונקציית עצירה
def stop():
    global stop_attack
    stop_attack = True
    log_text.insert(tk.END, "Attack stopped.\n")
    log_text.see(tk.END)

# פונקציה להוספת tooltip
def add_tooltip(widget, text):
    tooltip = tk.Toplevel(widget)
    tooltip.withdraw()
    tooltip.overrideredirect(True)
    label = tk.Label(tooltip, text=text, background="yellow", relief='solid', borderwidth=1, font=("Arial", 10))
    label.pack()

    def enter(event):
        tooltip.deiconify()
        x = event.x_root + 10
        y = event.y_root + 10
        tooltip.geometry(f"+{x}+{y}")

    def leave(event):
        tooltip.withdraw()

    widget.bind("<Enter>", enter)
    widget.bind("<Leave>", leave)

# יצירת GUI
root = tk.Tk()
root.title("SYN Flood - Demo Project")
root.geometry("450x450")

# שדות קלט
tk.Label(root, text="Target IP:").pack()
ip_entry = tk.Entry(root)
ip_entry.pack()

tk.Label(root, text="Port:").pack()
port_entry = tk.Entry(root)
port_entry.pack()

tk.Label(root, text="Packet Count:").pack()
count_entry = tk.Entry(root)
count_entry.pack()

# צ'קבוקס למצב הדגמה
demo_var = tk.BooleanVar()
demo_check = tk.Checkbutton(root, text="Demo Mode", variable=demo_var)
demo_check.pack(pady=5)
add_tooltip(demo_check, "Simulate attack without sending real packets")

# כפתור התחלה
tk.Button(root, text="Start Attack", command=start_attack).pack(pady=5)

# כפתור עצירה
tk.Button(root, text="Stop Attack", command=stop).pack(pady=5)

# תיבת לוג
log_text = tk.Text(root, height=15, width=55)
log_text.pack(pady=10)

root.mainloop()
